import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import {RouterModule} from "@angular/router";

import { BlogListComponent } from './Blog/Blog-list/blog-list.component';
import { HomeComponent } from './Home/Home.component';
@NgModule({
  declarations: [
    AppComponent,
    BlogListComponent,
    HomeComponent


  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot([
{path:'home',component:HomeComponent},
{path:'movies',component:BlogListComponent},
{path:'',redirectTo:'home',pathMatch:'full'},
{path:'**',redirectTo:'home',pathMatch:'full'}



    ])



  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
